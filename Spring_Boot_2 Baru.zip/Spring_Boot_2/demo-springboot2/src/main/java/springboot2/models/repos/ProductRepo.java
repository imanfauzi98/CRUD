package springboot2.models.repos;

import java.util.List;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;

import springboot2.models.entities.Product;
public interface ProductRepo extends CrudRepository <Product, Long> {
    List<Product> findByNameContains (String name);
    
}
