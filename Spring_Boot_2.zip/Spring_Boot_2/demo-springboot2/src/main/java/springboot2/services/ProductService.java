package springboot2.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import springboot2.models.entities.Product;
import springboot2.models.repos.ProductRepo;

@Service
@Transactional
public class ProductService {
    private ProductRepo productRepo;

    public Product save(Product product){
        return productRepo.save(product);
    }

    public Product findOne(Long id){
        return productRepo.findById(id).get();
    }

    public Iterable<Product> findAll(){
        return productRepo.findAll();
    }

    public void removeOne(Long id){
        productRepo.deleteById(id);
    }

    public List<Product> findByName(String name){
        return productRepo.findByNameContains(name);
    }

    
    
}
